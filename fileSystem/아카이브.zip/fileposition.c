#include "fileposition.h"
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
typedef char* String;

void fileposition(String file){
    // String ptr = (String)malloc(sizeof(char)*(4+strlen(file)));
    // printf("%s\n", file);

    chdir("src/"); 

 
    // while (ptr2 != NULL)
    // {
        
    //     chdir(ptr2);     //자른 문자 출력
    //     ptr2 = strtok(NULL, "/");
    // }


    // strcpy(file, ptr);

    // printf("file = %s\n", file);
    // printf("ptr = %s\n", ptr);

    // free(ptr);
}