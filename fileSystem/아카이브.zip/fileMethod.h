#include<stdio.h>

typedef char* String;

int fileAdd();
int fileRead();