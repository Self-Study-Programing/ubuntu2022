#include<stdio.h>

void fileposition(char* file);